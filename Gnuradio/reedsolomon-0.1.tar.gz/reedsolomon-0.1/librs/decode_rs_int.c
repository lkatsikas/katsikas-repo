#define BIGSYM 1
#include "decode_rs.c"
