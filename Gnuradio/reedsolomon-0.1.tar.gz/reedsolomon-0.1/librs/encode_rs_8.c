#define FIXED 1
#include "encode_rs.c"
