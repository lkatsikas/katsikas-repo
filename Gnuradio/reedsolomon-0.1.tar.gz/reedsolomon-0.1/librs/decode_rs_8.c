#define FIXED 1
#include "decode_rs.c"
