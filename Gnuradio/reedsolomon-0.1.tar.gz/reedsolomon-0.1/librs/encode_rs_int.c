#define BIGSYM 1
#include "encode_rs.c"
