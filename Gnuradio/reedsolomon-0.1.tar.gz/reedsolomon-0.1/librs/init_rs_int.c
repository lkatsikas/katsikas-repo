#define BIGSYM 1
#include "init_rs.c"
